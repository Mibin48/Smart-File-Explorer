#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <arpa/inet.h>

#define SERVER_PORT 5000

int main() {
    int sockfd;
    struct sockaddr_in serv_addr;
    char ch;

    printf("Client1: Enter a character: ");
    scanf(" %c", &ch);

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) { perror("socket"); exit(1); }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(SERVER_PORT);
    serv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (connect(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("connect");
        exit(1);
    }

    if (write(sockfd, &ch, 1) < 0) {
        perror("write");
        exit(1);
    }

    printf("Client1: sent '%c' to server\n", ch);
    close(sockfd);

    return 0;
}

