#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define SERVER_PORT 5000   // listens for client1
#define CLIENT2_PORT 6000  // sends to client2

int main() {
    int sockfd, newsockfd;
    struct sockaddr_in serv_addr, cli_addr;
    socklen_t cli_len;
    char buffer;

    // socket for client1
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) { perror("socket"); exit(1); }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(SERVER_PORT);

    if (bind(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("bind");
        exit(1);
    }

    listen(sockfd, 1);
    printf("Server: waiting for Client1...\n");

    cli_len = sizeof(cli_addr);
    newsockfd = accept(sockfd, (struct sockaddr*)&cli_addr, &cli_len);
    if (newsockfd < 0) { perror("accept"); exit(1); }

    // receive from client1
    if (read(newsockfd, &buffer, 1) < 0) {
        perror("read");
        exit(1);
    }
    printf("Server: received '%c' from Client1\n", buffer);

    close(newsockfd);
    close(sockfd);

    // decrement char
    if ((buffer > 'a' && buffer <= 'z') || (buffer > 'A' && buffer <= 'Z'))
        buffer--;

    // connect to client2
    int sockfd2 = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd2 < 0) { perror("socket"); exit(1); }

    struct sockaddr_in client2_addr;
    client2_addr.sin_family = AF_INET;
    client2_addr.sin_port = htons(CLIENT2_PORT);
    client2_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    printf("Server: connecting to Client2...\n");
    sleep(1); // give client2 time to be ready

    if (connect(sockfd2, (struct sockaddr*)&client2_addr, sizeof(client2_addr)) < 0) {
        perror("connect");
        exit(1);
    }

    if (write(sockfd2, &buffer, 1) < 0) {
        perror("write");
        exit(1);
    }

    printf("Server: sent '%c' to Client2\n", buffer);
    close(sockfd2);

    return 0;
}

