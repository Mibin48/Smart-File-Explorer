#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>

#define SERVER_PORT 5000

int main() {
    int sockfd;
    struct sockaddr_in serv_addr;
    float num;

    printf("Client1: Enter a float value: ");
    scanf("%f", &num);

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) { perror("socket"); exit(1); }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(SERVER_PORT);
    serv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (connect(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("connect");
        exit(1);
    }

    if (write(sockfd, &num, sizeof(float)) < 0) {
        perror("write");
        exit(1);
    }

    printf("Client1: sent %.2f to server\n", num);

    close(sockfd);
    return 0;
}

