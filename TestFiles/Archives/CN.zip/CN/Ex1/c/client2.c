#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>

struct Data {
    char c;
    int i;
    float f;
};

int main() {
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in servaddr;

    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(6000);
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    connect(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr));

    struct Data d;

    recv(sockfd, &d, sizeof(d), 0);

    printf("Received from Server (modified): c=%c, i=%d, f=%f\n", d.c, d.i, d.f);

    close(sockfd);
    return 0;
}

