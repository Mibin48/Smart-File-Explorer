#include <stdio.h>
#include <unistd.h>
#include <arpa/inet.h>

struct Data {
    char c;
    int i;
    float f;
};

int main() {
    printf("Waiting for Client1 connection...\n");
    int listenfd = socket(AF_INET, SOCK_STREAM, 0);

    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(5000);  
    addr.sin_addr.s_addr = INADDR_ANY;

    bind(listenfd, (struct sockaddr*)&addr, sizeof(addr));
    listen(listenfd, 1);

    int connfd = accept(listenfd, NULL, NULL);
    printf("Client1 connected!\n");

    struct Data d;
    recv(connfd, &d, sizeof(d), 0);
    printf("Received from Client1: c=%c, f=%f, i=%d\n", d.c, d.f, d.i);
    d.c++;;
    d.f += 10.0f;
    d.i += 1000;
    printf("Modified data for Client2: c=%c, f=%f, i=%d\n", d.c, d.f, d.i);

    close(connfd);
    close(listenfd);

    printf("Waiting for Client2 connection...\n");

    int listenfd2 = socket(AF_INET, SOCK_STREAM, 0);

    struct sockaddr_in addr2;
    addr2.sin_family = AF_INET;
    addr2.sin_port = htons(6000);
    addr2.sin_addr.s_addr = INADDR_ANY;

    bind(listenfd2, (struct sockaddr*)&addr2, sizeof(addr2));
    listen(listenfd2, 1);

    int connfd2 = accept(listenfd2, NULL, NULL);
    printf("Client2 connected!\n");

    send(connfd2, &d, sizeof(d), 0);
    printf("Sent modified data to Client2\n");

    close(connfd2);
    close(listenfd2);

    return 0;
}

