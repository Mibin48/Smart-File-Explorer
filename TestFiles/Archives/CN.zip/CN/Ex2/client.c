#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 5000
#define BUFSIZE 1024

int main() {
    int sockfd;
    struct sockaddr_in serv_addr;
    char buffer[BUFSIZE], recvbuf[BUFSIZE];

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) { perror("socket"); exit(1); }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
    serv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (connect(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("connect");
        exit(1);
    }

    while (1) {
        printf("Client: Enter message: ");
        fflush(stdout);

        memset(buffer, 0, BUFSIZE);
        fgets(buffer, BUFSIZE, stdin);

        buffer[strcspn(buffer, "\n")] = '\0';  // remove newline

        write(sockfd, buffer, strlen(buffer));

        if (strncmp(buffer, "BYEBYE", 6) == 0) {
            printf("Client: termination signal sent. Closing.\n");
            break;
        }

        memset(recvbuf, 0, BUFSIZE);
        int n = read(sockfd, recvbuf, BUFSIZE-1);
        if (n <= 0) break;

        recvbuf[n] = '\0';
        printf("Client received: %s\n", recvbuf);
    }

    close(sockfd);
    return 0;
}

