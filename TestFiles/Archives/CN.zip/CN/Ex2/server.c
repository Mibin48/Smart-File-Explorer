#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <ctype.h>

#define PORT 5000
#define BUFSIZE 1024

// transformation function
void transform(char *msg) {
    for (int i = 0; msg[i] != '\0'; i++) {
        char c = msg[i];
        if (isalpha(c)) {
            if (c == 'Z') msg[i] = 'A';
            else if (c == 'z') msg[i] = 'a';
            else msg[i] = c + 1;
        } else if (isdigit(c)) {
            if (c == '9') msg[i] = '0';
            else msg[i] = c + 1;
        } else {
            msg[i] = '.';
        }
    }
}

int main() {
    int sockfd, newsockfd;
    struct sockaddr_in serv_addr, cli_addr;
    socklen_t cli_len;
    char buffer[BUFSIZE];

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) { perror("socket"); exit(1); }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(PORT);

    if (bind(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("bind");
        exit(1);
    }

    listen(sockfd, 1);
    printf("Server: waiting for client...\n");

    cli_len = sizeof(cli_addr);
    newsockfd = accept(sockfd, (struct sockaddr*)&cli_addr, &cli_len);
    if (newsockfd < 0) { perror("accept"); exit(1); }

    while (1) {
        memset(buffer, 0, BUFSIZE);
        int n = read(newsockfd, buffer, BUFSIZE-1);
        if (n <= 0) break;

        buffer[n] = '\0';
        printf("Server received: %s\n", buffer);

        if (strncmp(buffer, "BYEBYE", 6) == 0) {
            printf("Server: termination signal received. Closing.\n");
            break;
        }

        transform(buffer);

        write(newsockfd, buffer, strlen(buffer));
        printf("Server sent: %s\n", buffer);
    }

    close(newsockfd);
    close(sockfd);
    return 0;
}

