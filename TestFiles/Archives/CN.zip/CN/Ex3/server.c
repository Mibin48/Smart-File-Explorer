#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/select.h>

#define PORT 8080
#define MAX_CLIENTS 10
#define BUF_SIZE 1024

int main() {
    int server_fd, new_fd, client[MAX_CLIENTS] = {0};
    struct sockaddr_in addr;
    fd_set readfds;
    char buf[BUF_SIZE];
    socklen_t addrlen = sizeof(addr);

    // create TCP socket
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(PORT);
    bind(server_fd, (struct sockaddr*)&addr, sizeof(addr));
    listen(server_fd, 5);

    printf("Server listening on port %d...\n", PORT);

    while (1) {
        FD_ZERO(&readfds);
        FD_SET(server_fd, &readfds);
        int max_sd = server_fd;

        // add clients to set
        for (int i = 0; i < MAX_CLIENTS; i++) {
            if (client[i] > 0) FD_SET(client[i], &readfds);
            if (client[i] > max_sd) max_sd = client[i];
        }

        // wait for activity
        select(max_sd + 1, &readfds, NULL, NULL, NULL);

        // new connection
        if (FD_ISSET(server_fd, &readfds)) {
            new_fd = accept(server_fd, (struct sockaddr*)&addr, &addrlen);
            for (int i = 0; i < MAX_CLIENTS; i++) {
                if (client[i] == 0) { client[i] = new_fd; break; }
            }
            printf("New client connected\n");
        }

        // check client messages
        for (int i = 0; i < MAX_CLIENTS; i++) {
            int sd = client[i];
            if (sd > 0 && FD_ISSET(sd, &readfds)) {
                int n = read(sd, buf, BUF_SIZE);
                if (n <= 0) {
                    close(sd);
                    client[i] = 0;
                    printf("Client disconnected\n");
                } else {
                    buf[n] = '\0';
                    printf("Client says: %s", buf);
                    // broadcast to others
                    for (int j = 0; j < MAX_CLIENTS; j++) {
                        if (client[j] > 0 && client[j] != sd) {
                            send(client[j], buf, n, 0);
                        }
                    }
                }
            }
        }
    }
}

