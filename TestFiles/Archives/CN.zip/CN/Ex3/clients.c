#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/select.h>

#define PORT 8080
#define BUF_SIZE 1024

int main() {
    int sock;
    struct sockaddr_in server_addr;
    char buf[BUF_SIZE];

    // create socket
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("Socket failed");
        exit(1);
    }

    // setup server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    // connect to server
    if (connect(sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connect failed");
        exit(1);
    }

    printf("Connected to chat server. Type messages and press Enter.\n");

    while (1) {
        fd_set fds;
        FD_ZERO(&fds);
        FD_SET(STDIN_FILENO, &fds); // input from keyboard
        FD_SET(sock, &fds);         // messages from server
        int max_fd = (sock > STDIN_FILENO ? sock : STDIN_FILENO) + 1;

        // wait for activity
        select(max_fd, &fds, NULL, NULL, NULL);

        // check keyboard input
        if (FD_ISSET(STDIN_FILENO, &fds)) {
            int n = read(STDIN_FILENO, buf, BUF_SIZE);
            if (n > 0) {
                send(sock, buf, n, 0);
            }
        }

        // check server messages
        if (FD_ISSET(sock, &fds)) {
            int n = read(sock, buf, BUF_SIZE);
            if (n <= 0) {
                printf("Server closed connection.\n");
                close(sock);
                break;
            }
            buf[n] = '\0';
            printf(">> %s", buf);
        }
    }

    return 0;
}

