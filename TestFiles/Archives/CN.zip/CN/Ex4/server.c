#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <arpa/inet.h>

#define TCP_PORT 5000
#define UDP_PORT 6000
#define BUFSIZE 1024

// factorial function
unsigned long long factorial(int n) {
    if (n < 0) return 0; // invalid
    unsigned long long fact = 1;
    for (int i = 1; i <= n; i++) fact *= i;
    return fact;
}

// --- TCP thread handler ---
void* handle_tcp_client(void* arg) {
    int sock = *(int*)arg;
    free(arg);

    int num;
    while (1) {
        int n = read(sock, &num, sizeof(int));
        if (n <= 0) break;

        unsigned long long result = factorial(num);

        write(sock, &result, sizeof(result));
        printf("[TCP] Client requested %d -> %llu\n", num, result);
    }

    close(sock);
    return NULL;
}

// --- UDP handler thread ---
void* handle_udp(void* arg) {
    int udp_sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (udp_sock < 0) { perror("UDP socket"); exit(1); }

    struct sockaddr_in udp_addr, client_addr;
    socklen_t len = sizeof(client_addr);

    udp_addr.sin_family = AF_INET;
    udp_addr.sin_addr.s_addr = INADDR_ANY;
    udp_addr.sin_port = htons(UDP_PORT);

    if (bind(udp_sock, (struct sockaddr*)&udp_addr, sizeof(udp_addr)) < 0) {
        perror("UDP bind");
        exit(1);
    }

    printf("UDP server listening on port %d...\n", UDP_PORT);

    while (1) {
        int num;
        int n = recvfrom(udp_sock, &num, sizeof(int), 0,
                         (struct sockaddr*)&client_addr, &len);
        if (n <= 0) continue;

        unsigned long long result = factorial(num);

        sendto(udp_sock, &result, sizeof(result), 0,
               (struct sockaddr*)&client_addr, len);

        printf("[UDP] Client requested %d -> %llu\n", num, result);
    }
    close(udp_sock);
    return NULL;
}

// --- Main server ---
int main() {
    int server_fd, new_socket;
    struct sockaddr_in address;
    int addrlen = sizeof(address);

    // TCP socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("TCP socket failed");
        exit(EXIT_FAILURE);
    }

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(TCP_PORT);

    if (bind(server_fd, (struct sockaddr*)&address, sizeof(address)) < 0) {
        perror("TCP bind failed");
        exit(EXIT_FAILURE);
    }

    if (listen(server_fd, 5) < 0) {
        perror("listen");
        exit(EXIT_FAILURE);
    }

    printf("TCP server listening on port %d...\n", TCP_PORT);

    // launch UDP handler thread
    pthread_t udp_thread;
    pthread_create(&udp_thread, NULL, handle_udp, NULL);

    // accept TCP clients
    while (1) {
        new_socket = accept(server_fd, (struct sockaddr*)&address, (socklen_t*)&addrlen);
        if (new_socket < 0) {
            perror("accept");
            continue;
        }

        printf("New TCP client connected.\n");
        pthread_t tid;
        int* pclient = malloc(sizeof(int));
        *pclient = new_socket;
        pthread_create(&tid, NULL, handle_tcp_client, pclient);
        pthread_detach(tid);
    }

    close(server_fd);
    return 0;
}

