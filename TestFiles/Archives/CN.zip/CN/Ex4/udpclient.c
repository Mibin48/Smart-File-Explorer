#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>

#define UDP_PORT 6000

int main() {
    int sock;
    struct sockaddr_in serv_addr;
    int num;
    unsigned long long result;
    socklen_t len = sizeof(serv_addr);

    sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) { perror("socket"); exit(1); }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(UDP_PORT);
    serv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    while (1) {
        printf("Enter a number (-1 to quit): ");
        scanf("%d", &num);
        if (num < 0) break;

        sendto(sock, &num, sizeof(num), 0, (struct sockaddr*)&serv_addr, len);
        recvfrom(sock, &result, sizeof(result), 0, (struct sockaddr*)&serv_addr, &len);

        printf("Factorial: %llu\n", result);
    }

    close(sock);
    return 0;
}

